import os
import sys
# Flask
from flask import Flask, redirect, url_for, request, render_template, Response, jsonify, redirect
from werkzeug.utils import secure_filename
#from gevent.pywsgi import WSGIServer

# TensorFlow and tf.keras
import tensorflow
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import load_img, img_to_array

# Some utilites
import numpy as np
from util import base64_to_pil, np_to_base64

# Declare a flask app
app = Flask(__name__)

# Model saved with Keras model.save()
MODEL_PATH = 'models/simpsons.h5'
# Load your own trained model
model = load_model(MODEL_PATH)
IMG_DIM = (224, 224)

class_map = {0: 'abe_grampa_simpson', 1: 'agnes_skinner', 2: 'apu_nahasapeemapetilon',
 3: 'barney_gumble', 4: 'bart_simpson', 5: 'carl_carlson', 6: 'c.m._burns',
 7: 'chief_wiggum', 8: 'cletus_spuckler', 9: 'comic_book_guy', 10: 'disco_stu', 11: 'edna_krabappel',
 12: 'fat_tony', 13: 'gil', 14: 'groundskeeper_willie', 15: 'homer_simpson', 16: 'kent_brockman',
 17: 'krusty_the_clown', 18: 'lenny_leonard', 19: 'lionel_hutz', 20: 'lisa_simpson', 21: 'maggie_simpson',
 22: 'marge_simpson', 23: 'martin_prince', 24: 'mayor_quimby', 25: 'milhouse_van_houten',
 26: 'miss_hoover', 27: 'moe_szyslak', 28: 'ned_flanders', 29: 'nelson_muntz', 30: 'otto_mann',
 31: 'patty_bouvier', 32: 'principal_skinner', 33: 'professor_john_frink', 34: 'rainier_wolfcastle',
 35: 'ralph_wiggum', 36: 'selma_bouvier', 37: 'sideshow_bob', 38: 'sideshow_mel', 39: 'snake_jailbird',
 40: 'troy_mcclure', 41: 'waylon_smithers'}

def model_predict(img, model):
    image = img_to_array(load_img(img,target_size=IMG_DIM))
    image = np.array(image)
    image = image.astype('float32')
    image = image.reshape(1,224,224,3)
    image = image / 255
    prediction = model.predict(image)
    prediction_class = class_map[np.argmax(prediction, axis=1)[0]]
    prediction_prob = np.max(prediction)
    return prediction_class, prediction_prob

@app.route('/', methods=['GET'])
def index():
    # Main page
    return render_template('index.html')


@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        # Get the image from post request
        img = base64_to_pil(request.json)
        img.save("./uploads/image.png")
        img_path = "./uploads/image.png"
        # Make prediction
        predicted_class, predicted_prob = model_predict(img_path, model)
        pred_proba = "{:.3f}".format(predicted_prob)
        # Serialize the result, you can add additional fields
        return jsonify(result=str(predicted_class)+"-"+"Prob: "+pred_proba)
    return None

if __name__ == '__main__':
    #app.run(port=5002, threaded=False)
    app.run(debug=True)
    # Serve the app with gevent
    #http_server = WSGIServer(('0.0.0.0', 5000), app)
    #http_server.serve_forever()